export const exampleData = [
  {
      "user_id": 9353,
      "id": 1,
      "sugar_id": "413",
      "lvl": 4,
      "percentage": 25,
      "prev_position": 322,
      "count": 5089.27
  },
  {
      "user_id": 9354,
      "id": 2,
      "sugar_id": "k10307k10307k10307k10307",
      "lvl": 4,
      "percentage": 1000,
      "prev_position": 3,
      "count": 5089.27
  },
  {
      "user_id": 9355,
      "id": 3,
      "sugar_id": "k10307",
      "lvl": 2,
      "percentage": 63,
      "prev_position": 2,
      "count": 5089.27
  },
  {
      "user_id": 93556,
      "id": 4,
      "sugar_id": "k10307",
      "lvl": 1,
      "percentage": 63,
      "prev_position": 4,
      "count": 5089.27
  },
  {
      "user_id": 93556,
      "id": 5,
      "sugar_id": "k10307",
      "lvl": 1,
      "percentage": 63,
      "prev_position": 2,
      "count": 5089.27
  },
  {
      "user_id": 9354,
      "id": 6,
      "sugar_id": "k10307",
      "lvl": 4,
      "percentage": 100,
      "prev_position": 3,
      "count": 5089.27
  },
  {
      "user_id": 9355,
      "id": 7,
      "sugar_id": "k10307",
      "lvl": 2,
      "percentage": 63,
      "prev_position": 2,
      "count": 5089.27
  },
  {
      "user_id": 93556,
      "id": 8,
      "sugar_id": "k10307",
      "lvl": 1,
      "percentage": 63,
      "prev_position": 4,
      "count": 5089.27
  },
  {
      "user_id": 93556,
      "id": 9,
      "sugar_id": "k10307",
      "lvl": 1,
      "percentage": 63,
      "prev_position": 2,
      "count": 5089.27
  },
  {
      "user_id": 9353,
      "id": 10,
      "sugar_id": "k10307",
      "lvl": 4,
      "percentage": 25,
      "prev_position": 322,
      "count": 5089.27
  }
]