import FooterNav from './FooterNav.vue'

export default FooterNav